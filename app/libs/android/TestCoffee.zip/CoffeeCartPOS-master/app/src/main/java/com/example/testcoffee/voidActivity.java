package com.example.testcoffee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class voidActivity extends AppCompatActivity {
    EditText et_ecrVd, et_refVd;
    Button btn_voidTrans, btn_cancel;
    int voidAmt, ecrV, refV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_void);
        btn_voidTrans = findViewById(R.id.btn_voidTrans);
        btn_cancel = findViewById(R.id.btn_cancel);
        et_ecrVd = findViewById(R.id.et_ecrVd);
        et_refVd = findViewById(R.id.et_refVd);

        btn_voidTrans.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // gets called when clicked

                String stringEcrVoid = et_ecrVd.getText().toString();
                String stringRefVoid = et_refVd.getText().toString();

                ecrV = Integer.parseInt(stringEcrVoid);
                refV= Integer.parseInt(stringRefVoid);

                //Change later when fixing UI
                Intent data = new Intent();
                data.putExtra("ECR_VOID", ecrV);
                data.putExtra("REF_VOID",refV);
                setResult(RESULT_OK, data);
                // setResult(RESULT_CODE,data);
                finish();
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // gets called when clicked


                //Change later when fixing UI
                Intent data = new Intent();
                setResult(RESULT_OK, data);
                // setResult(RESULT_CODE,data);
                finish();
            }
        });
    }

}