package com.example.testcoffee;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class refundActivity extends AppCompatActivity {
    EditText et_refundAmt;
    Button btn_refund;
    int refund;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refund);
        et_refundAmt = findViewById(R.id.et_refundAmt);
        btn_refund = findViewById(R.id.btn_refund);


        btn_refund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // gets called when clicked

                String stringRefund = et_refundAmt.getText().toString();
                refund = Integer.parseInt(stringRefund);

                //Change later when fixing UI
                Intent data = new Intent();
                data.putExtra("REFUND", refund);
                setResult(RESULT_OK, data);
                // setResult(RESULT_CODE,data);
                finish();
            }
        });

    }
}