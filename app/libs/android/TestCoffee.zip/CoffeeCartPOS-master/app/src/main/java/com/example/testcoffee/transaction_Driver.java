package com.example.testcoffee;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Button;
import android.widget.TextView;

import com.pax.poslink.BatchRequest;
import com.pax.poslink.BatchResponse;
import com.pax.poslink.CommSetting;
import com.pax.poslink.ManageRequest;
import com.pax.poslink.ManageResponse;
import com.pax.poslink.PaymentRequest;
import com.pax.poslink.PaymentResponse;
import com.pax.poslink.PosLink;
import com.pax.poslink.ProcessTransResult;
import com.pax.poslink.ReportRequest;
import com.pax.poslink.ReportResponse;
import com.pax.poslink.poslink.POSLinkCreator;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.lang.ref.WeakReference;
import java.util.Random;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


/*
typeTransaction dictates what will be run:
0--> Getting Start up info
1--> Process Sale
2--> Lookup by ECR AND REF numbers
3--> Report
4--> Refund
5--> Void
6--> Close Batch
 */

@SuppressWarnings("deprecation")
public class transaction_Driver extends AsyncTask<Integer, Void, String> {
    private static Integer typeTransaction;
    final String SERIAL_NUMBER= "1440000571";
    Button btn_tran_sale;
    TextView tv_version, tv_serialNm, tv_appNm, tv_gtot;
    String applicationName, applicationVersion, serialNumber, transDateTime,
            acctNm, cardType,transType, apprvdamt, ecrRef, authCode,
            hostCode, hostResponse, hostMessage, refNum, nameCard, transDate, transTime;
    private WeakReference<MainActivity> activityWeakReference;
    private WeakReference<Context> contextWeakReference;
    String status, cardName;
    DatabaseHelper dataBaseHelper;



    public void setStatus(String status) {
        this.status = status;
    }

    //Weak reference to activity
    transaction_Driver(MainActivity activity){
        activityWeakReference = new WeakReference<MainActivity>(activity);
    }
    //Weak reference to context
    transaction_Driver(Context context){
        contextWeakReference = new WeakReference<Context>(context);
    }
    //Weak reference to both
    transaction_Driver(MainActivity activity,Context context){
        activityWeakReference = new WeakReference<MainActivity>(activity);
        contextWeakReference = new WeakReference<Context>(context);
    }
    @Override
    protected String doInBackground(Integer... type) {
        typeTransaction = type[0];
        switch (typeTransaction){
            case 0:
                System.out.println("Attempting to get app info");
                getAppInfo();
                break;
            case 1:
                System.out.println("Attempting to process sale");
                if(type[1] != null){
                    processPayment(type[1]);
                }
                break;
            case 2:
                System.out.println("Attempting to look up transaction based off ECR and REF numbers");
                if(type[1] != null && type[2] != null){
                    processLookUp(1,type[1], type[2]);
                }

                break;
            case 3:
                System.out.println("Attempting to make up a report");
                makeReport();

                break;
            case 4:
                System.out.println("Attempting to process Refund");
                if(type[1] != null){
                    processRefund(type[1]);
                }
                break;
            case 5:
                System.out.println("Attempting to process Void");
                if(type[1] != null && type[2] != null){
                    processLookUp(2,type[1], type[2]);
                }
                break;
            case 6:
                System.out.println("Attempting to close batch");
                processCloseBatch();
                break;

            default:
                break;
        }

        return null;
    }
    public void processCloseBatch(){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);


        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        //Create a BatchRequest with a TransType BATCHCLOSE and EDCType CREDIT
        BatchRequest request = new BatchRequest();
        request.TransType = request.ParseTransType("BATCHCLOSE");
        request.ParseEDCType("CREDIT");
        posLink.BatchRequest = request;

        //Process the transaction
        ProcessTransResult result = posLink.ProcessTrans();

        //Check result code of the transaction
        if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
            BatchResponse response = posLink.BatchResponse;

            System.out.println( );
            System.out.println("CLOSE BATCH Results: " );
            System.out.println("========BATCH CLOSE RESULT CODE==== : "+response.ResultCode);
            System.out.println("========BATCH CLOSE RESULT CODE==== : "+response.ResultTxt);
            System.out.println("");

            String tid = response.TID;
            System.out.println("GOT A TID "+tid);

            System.out.println("TID: "+response.TID);
            System.out.println("MID: "+response.MID);
            System.out.println("Sale Totals: ");
            System.out.println("Tip Totals: ");
            System.out.println("Refund Amount :");
            System.out.println("Void Amount: ");
            System.out.println("BATCH CLOSED :"+response.Timestamp);


            System.out.println("");
            System.out.println("=======Close Batch Success============");
            setStatus("good");

        }
        else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
            System.out.println("=======Close Batch Failed============");
            //Go on to display the tags that failed if emv
        }
    }
    public void processVoid(int ecrV, int refV){

        System.out.println("VOIDING TRANSACTION: ");
        System.out.println("ECR: "+ecrV);
        System.out.println("REF: "+refV);
        System.out.println();

        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);

        System.out.println("checkpoint F VOID");

        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        //Create a PaymentRequest with a TransType RETURN and TenderType CREDIT
        PaymentRequest request = new PaymentRequest();
        request.TenderType = request.ParseTenderType("CREDIT");
        request.TransType = request.ParseTransType("VOID");



        //Generate a randomized reference number for the transaction
        ecrRef = genRandomECR();
        request.ECRRefNum = ecrRef;
        String ecrString = Integer.toString(ecrV);
        String refString = Integer.toString(refV);
        request.OrigECRRefNum = ecrString;
        request.OrigRefNum = refString;
        System.out.println("ECR REF for VOID TRANSACTION: "+ecrRef);
        System.out.println("ORIG ECR REF: "+ecrString);
        System.out.println("ORIG REF NUM: "+refString);


        //Entry mode - swipe, chip, contactless
        request.ExtData = "<EntryModeBitmap>01110000</EntryModeBitmap>";

        //Add request to PosLink, process transaction, store transaction result
        posLink.PaymentRequest = request;
        ProcessTransResult result = posLink.ProcessTrans();

        //Check result code of the transaction
        if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){

            PaymentResponse response = posLink.PaymentResponse;

            System.out.println( );
            System.out.println("VOID Results: " );
            System.out.println("========VOID RESULT CODE==== : "+response.ResultCode);
            System.out.println("========VOID RESULT CODE==== : "+response.ResultTxt);
            System.out.println("");
            System.out.println("=======Void success==========");
            System.out.println("TIME/DATE OF VOIDED TRANSACTION: "+response.Timestamp);
            System.out.println("");

            setStatus("good");

        }
        else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
            System.out.println("=======Void Failed============");
            //Go on to display the tags that failed if emv
        }

    }
    public void processRefund(int amt){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);

        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        //Create a PaymentRequest with a TransType RETURN and TenderType CREDIT
        PaymentRequest request = new PaymentRequest();
        request.TenderType = request.ParseTenderType("CREDIT");
        request.TransType = request.ParseTransType("RETURN");


        //Generate a randomized reference number for the transaction
        ecrRef = genRandomECR();
        request.ECRRefNum = ecrRef;

        //Set the auth amount for the refund transaction
        String ttl = Integer.toString(amt);
        request.Amount = ttl;

        //Entry mode - swipe, chip, contactless
        request.ExtData = "<EntryModeBitmap>01110000</EntryModeBitmap>";

        //Add request to PosLink, process transaction, store transaction result
        posLink.PaymentRequest = request;
        ProcessTransResult result = posLink.ProcessTrans();

        //Check result code of the transaction
        if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
            //Save info as strings
            PaymentResponse response = posLink.PaymentResponse;
            String extData = response.ExtData;
            tagReader(1,extData); //1 for cardholder name

            System.out.println("=======Refund success==========");
            System.out.println( );
            System.out.println("Refund Results: " );
            System.out.println("========REFUND RESULT CODE ==== : "+response.ResultCode);
            System.out.println("========REFUND RESULT CODE ==== : "+response.ResultTxt);

            transDateTime = response.Timestamp;
            acctNm = response.BogusAccountNum;
            cardType = response.CardType;
            transType = "RETURN"; //Change me
            apprvdamt = response.ApprovedAmount;
            authCode = response.AuthCode;
            hostCode = response.HostCode;
            hostResponse = response.HostResponse;
            hostMessage = response.Message;
            refNum = response.RefNum;
           // nameCard = nameCard; //Change me

            setStatus("good");
            displayTransResults();



        }
        else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
            System.out.println("=======Refund Failed============");
            //Go on to display the tags that failed if emv
        }

    }
    public void makeReport(){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);

        System.out.println("checkpoint D REPORT");

        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        //Create a ReportRequest with  TransType LOCALTOTALREPORT
        ReportRequest request = new ReportRequest();
        request.TransType = request.ParseTransType("LOCALTOTALREPORT");
        request.EDCType = request.ParseEDCType("ALL");

        posLink.ReportRequest = request;
        ProcessTransResult result = posLink.ProcessTrans();

        if(result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
            ReportResponse res = posLink.ReportResponse;
            System.out.println("CREATING A 'LOCALTOTALREPORT' FOR ALL EDC TYPES");

            System.out.println("EDC TYPE COUNT: ");
            System.out.println("CREDIT COUNT : "+res.CreditCount);
            System.out.println("DEBIT COUNT: "+res.DebitCount);
            System.out.println("EBT COUNT: "+res.EBTCount);
            System.out.println("GIFT COUNT: "+res.GiftCount);
            System.out.println("LOYALTY COUNT: "+res.LoyaltyCount);
            System.out.println("CASH COUNT: "+res.CashCount);
            System.out.println("CHECK COUNT: "+res.CHECKCount);
            System.out.println("===============================");
            System.out.println("EDC TYPE AMOUNT: ");
            System.out.println("CREDIT AMOUNT : "+res.CreditAmount);
            System.out.println("DEBIT AMOUNT: "+res.DebitAmount);
            System.out.println("EBT AMOUNT : "+res.EBTAmount);
            System.out.println("GIFT AMOUNT : "+res.GiftAmount);
            System.out.println("LOYALTY AMOUNT : "+res.LoyaltyAmount);
            System.out.println("CASH AMOUNT : "+res.CashAmount);
            System.out.println("CHECK AMOUNT : "+res.CHECKAmount);


        } else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
            System.out.println("===Report Failed===");
        }
    }
    public void processLookUp(int type, int ecr, int ref){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);


        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        if(type==1){
            ReportRequest request = new ReportRequest();
            request.TransType = request.ParseTransType("LOCALDETAILREPORT");
            request.EDCType = request.ParseEDCType("CREDIT");

            String ECRN = Integer.toString(ecr);
            String REFN = Integer.toString(ref);

            request.ECRRefNum = ECRN;
            request.RefNum = REFN;
            posLink.ReportRequest = request;

            //Process the transaction and store the transaction result
            ProcessTransResult result = posLink.ProcessTrans();

            if(result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
                ReportResponse res = posLink.ReportResponse;
                Context ctxt = contextWeakReference.get();
                System.out.println("SEARCHING FOR "+ecr+" and "+ref);
                // DatabaseHelper databaseHelper = new DatabaseHelper(ctxt);
                // databaseHelper.getSpecific(ECRN, REFN,"DATE_AND_TIME");
                System.out.println("=======LOOKUP success==========");

                System.out.println("========LOOKUP CODE ==== : "+res.ResultCode);
                System.out.println("========LOOKUP RESULT CODE ==== : "+res.ResultTxt);

                transDateTime = res.Timestamp;
                acctNm = res.BogusAccountNum;
                cardType = res.CardType;
                transType = "LOCALDETAILREPORT";
                apprvdamt = res.ApprovedAmount;
                ecrRef = res.ECRRefNum;
                authCode = res.AuthCode;
                hostCode = res.HostCode;
                hostResponse = res.HostResponse;
                hostMessage = res.HostDetailedMessage;

                status = "good";
                displayTransResults();

            } else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
                System.out.println("===========LOOKUP failed===========");
            }
        }else{
            ReportRequest request = new ReportRequest();
            request.TransType = request.ParseTransType("LOCALDETAILREPORT");
            request.EDCType = request.ParseEDCType("CREDIT");

            String ECRN = Integer.toString(ecr);
            String REFN = Integer.toString(ref);

            request.ECRRefNum = ECRN;
            request.RefNum = REFN;
            posLink.ReportRequest = request;

            //Process the transaction and store the transaction result
            ProcessTransResult result = posLink.ProcessTrans();

            if(result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
                ReportResponse res = posLink.ReportResponse;

                Context ctxt = contextWeakReference.get();
                System.out.println("SEARCHING FOR "+ecr+" and "+ref);
                // DatabaseHelper databaseHelper = new DatabaseHelper(ctxt);
                // databaseHelper.getSpecific(ECRN, REFN,"DATE_AND_TIME");
//                String extData = res.ExtData;
//                tagReader(2, extData); //Get transType

                transDateTime =res.Timestamp;
                acctNm = res.BogusAccountNum;
                cardType = res.CardType;
                transType = "VOID";
                apprvdamt = res.ApprovedAmount;
                ecrRef = res.ECRRefNum;
                authCode = res.AuthCode;
                hostCode = res.HostCode;
                hostResponse = res.HostResponse;
                hostMessage = res.HostDetailedMessage;
                status = "good";
                System.out.println("Attempting to VOID :");
                //Display Results of Search
                displayTransResults();

                processVoid(ecr,ref);

            } else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
                System.out.println("Transaction for: ECR: "+ecr+" REF: "+ref+" FAILED");
            }

        }

    }
    public void processPayment(int total){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);


        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);

        //Create a PaymentRequest with a TransType AUTH and TenderType CREDIT
        PaymentRequest request = new PaymentRequest();
        request.TenderType = request.ParseTenderType("CREDIT");
        request.TransType = request.ParseTransType("SALE");

        //Allow for signature and tips
        request.TransactionBehavior.SignatureUploadFlag = "1";
        request.TransactionBehavior.SignatureAcquireFlag = "1";
        request.TransactionBehavior.SignatureCaptureFlag = "1";
        request.TransactionBehavior.TipRequestFlag = "1";

        //Generate a randomized reference number for the transaction
        ecrRef = genRandomECR();
        request.ECRRefNum = ecrRef;

        //Set the auth amount for the transaction
        String ttl = Integer.toString(total);
        request.Amount = ttl;

        //Entry mode - swipe, chip, contactless
        request.ExtData = "<EntryModeBitmap>01110000</EntryModeBitmap>";

        //Add request to PosLink, process transaction, store transaction result
        posLink.PaymentRequest = request;
        ProcessTransResult result = posLink.ProcessTrans();

        //Check result code of the transaction
        if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)){
            //Save info as strings
            PaymentResponse response = posLink.PaymentResponse;

            String extData = response.ExtData;
            tagReader(1,extData); //1 for cardholder name

            transDateTime = response.Timestamp;
            acctNm = response.BogusAccountNum;
            cardType = response.CardType;
            transType = "SALE"; //Change me
            apprvdamt = response.ApprovedAmount;
            authCode = response.AuthCode;
            hostCode = response.HostCode;
            hostResponse = response.HostResponse;
            hostMessage = response.Message;
            refNum = response.RefNum;
            nameCard = cardName; //Change me

            setStatus("good");
            System.out.println("=======Payment success==========");

            System.out.println("========PAYMENT RESULT CODE ==== : "+response.ResultCode);
            System.out.println("========PAYMENT RESULT CODE ==== : "+response.ResultTxt);
            System.out.println("PAYMENT REF 1: "+refNum);
            System.out.println("PAYMENT ECR 1: "+ecrRef);
            displayTransResults(); //USE ME UNTIL FB STOPS OVERRIDING SALES




        }
        else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)){
            System.out.println("=======Payment Failed============");
            //Go on to display the tags that failed if emv
        }

    }
    public String genRandomECR(){
        Random rand = new Random();
        int rand_ecr = rand.nextInt(1000);
        String rnd_ecr = Integer.toString(rand_ecr);
        return rnd_ecr;
    }
    public String getAppInfo(){
        //Set commSetting
        CommSetting commSetting = new CommSetting();
        commSetting.setType(CommSetting.AIDL);

        // Create POSLink object
        Context contxt = contextWeakReference.get();
        PosLink posLink = POSLinkCreator.createPoslink(contxt);
        posLink.SetCommSetting(commSetting);
        //Grab info
        ManageRequest request = new ManageRequest();
        request.TransType = request.ParseTransType("INIT");
        posLink.ManageRequest = request;
        ProcessTransResult result = posLink.ProcessTrans();

        if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.OK)) {
            ManageResponse response = posLink.ManageResponse;
            applicationName = posLink.ManageResponse.DeviceInfo.AppName;
            applicationVersion = posLink.ManageResponse.DeviceInfo.AppVersion;
            setStatus("good");
            return status;


        } else if (result.Code.equals(ProcessTransResult.ProcessTransResultCode.ERROR)) {
            System.out.println("//////BAD REQUEST///");

            setStatus("bad");
            return status;

        } else {
            System.out.println("//////ERROR///");
            setStatus("error");
            return status;
        }
    }
    @Override
    protected void onPostExecute(String s){
        super.onPostExecute(s);
        Context ctxt = contextWeakReference.get();
        transactionModel transactionModel;
        dataBaseHelper = new DatabaseHelper(ctxt);
        MainActivity activity = activityWeakReference.get();

        if (!doesExist(activity)){
            System.out.println("Checkpoint POST EXECUTE FAILED");
            return;} //Make sure activity exists
        System.out.println("At on POST EXECUTE///");
        if(typeTransaction == 0 && status == "good"){
            //Setting TextViews appropriate value
            System.out.println("//////SETTING TEXT///");
            System.out.println("------APP NAME: "+applicationName);
            System.out.println("------SERIAL: "+SERIAL_NUMBER);
            System.out.println("------APP VERSION: "+applicationVersion);

            activity.tv_appNm.setText(applicationName);
            activity.tv_serialNm.setText(SERIAL_NUMBER);
            activity.tv_version.setText(applicationVersion);
        }
        else if(typeTransaction == 1 && status == "good"){
            System.out.println("ECR NUM: "+ecrRef);
            System.out.println("Ref Num: "+refNum);
//            Context ctxt = contextWeakReference.get();
        //    transactionModel transactionModel;
//            dataBaseHelper = new DatabaseHelper(ctxt);
            try {
                   // System.out.println("Inserting sale into DB");
                    transactionModel = new transactionModel( -1, transDateTime, acctNm,
                            cardType, transType, apprvdamt, ecrRef, nameCard, authCode, hostCode, hostResponse, hostMessage, refNum);
                    //System.out.println("Success adding transaction to db");
                    //displayTransResults(); //USE ME UNTIL FB STOPS OVERRIDING SALES

            }catch (Exception e) {
               // System.out.println("Cannot to insert DB");
                transactionModel = new transactionModel( -1, "error", "error",
                        "error", "error", "error", "error", "error",
                        "error", "error", "error", "error", "error");

            }

            boolean success = dataBaseHelper.addOne(transactionModel);
        }
        else if (typeTransaction == 2 && status == "good"){

           // System.out.println("Lets check the db for a count"); **WHEN SEARCHING MADE DB IT IS OVERRIDING PER SALE PROBABLY WHERE CREAITNG DB INSTANCE
            dataBaseHelper = new DatabaseHelper(ctxt);
            dataBaseHelper.isEmpty();
//            displayTransResults();
        }
    }
    public boolean doesExist(MainActivity activity){
        if(activity != null || !activity.isFinishing()){
            //System.out.println("Activity exists");
            return true;
        }
        //System.out.println("Activity does NOT exist");
        return false;
    }
    public void displayTransResults(){
        System.out.println("Transaction Date/Time: "+transDateTime); //missing with LOOKUP
        System.out.println("Acct Num: "+acctNm);
        System.out.println("Card Type: "+cardType);
        System.out.println("Trans Type"+ transDateTime); //MISSING WITH LOOKUP
        System.out.println("Approved Amount: "+apprvdamt);
        System.out.println("authCode: "+authCode);
        System.out.println("Host Code: "+hostCode);
        System.out.println("Host Response: "+hostResponse);
        System.out.println("Host Message: "+hostMessage);
        System.out.println("Ref Num: "+refNum);
        System.out.println("Cardholders Name: "+nameCard);

    }
    public void tagReader(int tag, String extData){
        //1--> cardholders name
        //2--> transaction type
        //3-->
        extData = "<root>"+extData+"</root>";

        switch (tag){
            case 1:
                try{
                    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                    InputSource src = new InputSource();
                    src.setCharacterStream(new StringReader(extData));
                    Document doc = builder.parse(src);
                    cardName = doc.getElementsByTagName("PLNameOnCard").item(0).getTextContent();
                }
                catch(Exception e){
                    cardName = "Null Name";
                }
                break;
            case 2:
                try{
                    DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                    InputSource src = new InputSource();
                    src.setCharacterStream(new StringReader(extData));
                    Document doc = builder.parse(src);
                    transType = doc.getElementsByTagName("PLNameOnCard").item(0).getTextContent();
                }
                catch(Exception e){
                    transType = "UNKNOWN";
                }
                break;

            default:
                break;
        }
    }
}

