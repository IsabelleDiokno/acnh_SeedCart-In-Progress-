package com.example.testcoffee;

import android.app.FragmentManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import com.pax.poslink.LogSetting;
import com.pax.poslink.setting.POSLinkCommSettingListenerManager;


import com.pax.poslink.POSLinkAndroid;
import com.pax.poslink.PosLink;
import com.pax.poslink.poslink.POSLinkCreator;

@SuppressWarnings("deprecation")

public class MainActivity extends AppCompatActivity{
    TextView tv_version, tv_serialNm, tv_appNm;
    Button btn_tran_sale, btn_lookUp, btn_report, btn_refundTrans, btn_voidTrans,
    btn_clBatch;
    String grandT;
    /*
    Note that for requestCode for startActivityForResult:
    Result_Code:
    0-->Look up app info
    1-->Sale Results (grandTotal)
    2--> Look Up a transaction
    3--> Report
    4--> Refund
    5--> Void
    6--> Close Batch
     */


    @Override
    //public void onCreate(Bundle savedInstanceState) {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Buttons and Textviews
        btn_tran_sale = findViewById(R.id.btn_tran_sale);
        btn_lookUp = findViewById(R.id.btn_lookUp);
        btn_report = findViewById(R.id.btn_report);
        btn_refundTrans = findViewById(R.id.btn_refundTrans);
        btn_voidTrans = findViewById(R.id.btn_voidTrans);
        btn_clBatch = findViewById(R.id.btn_clBatch);


        tv_appNm = findViewById(R.id.tv_appNm);
        tv_serialNm = findViewById(R.id.tv_serialNm);
        tv_version = findViewById(R.id.tv_version);


/*        //POSLINK 1 - Init POSLink for Android
        Context context = getApplicationContext();
        POSLinkAndroid.init(context);
        //POSLINK 1- Init POSLink for Android
        POSLinkAndroid.init(context);
        retrieveInfo(this, context);*/

        //POSLINK 2 - Set log settings
        LogSetting logSetting = new LogSetting();
        //LogSetting.setEnable(true); //Not showing up
        LogSetting.setLevel(LogSetting.LOGLEVEL.DEBUG);
        LogSetting.setLogDays("30");
        LogSetting.setLogFileName("POSLog");
        LogSetting.setOutputPath("/poslink");
       // POSLinkSemi.getInstance().setLogSetting(logSetting); POSLinkSemi does not appear, is it my libraries?

        //POSLink 2 - Set Comm Setting
        AidlSetting aidlSetting = new AidleSetting ();
        aidlSetting.setTimeout(300000);

        // set a listener on Sale button
        btn_tran_sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { // gets called when clicked
                processSale(v);
            }
        });
        //Set a listener for Look Up button
        btn_lookUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { lookUp(v); }
        });
        //Set a listener for Report button
        btn_report.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { report(v); }
        });
        //Set a listener for Refund button
        btn_refundTrans.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { refund(v); }
        });
        //Set a listener for Void button
        btn_voidTrans.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { voidTransaction(v); }
        });
        //Set a listener for Void button
        btn_clBatch.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) { closeBatch(v); }
        });
    }
    public void closeBatch (View v){
        System.out.println("Going to close batch...");
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this, context);
        td.execute(6);
    }
    public void voidTransaction (View v){
        System.out.println("Starting Void.. ");
        Intent intent = new Intent(MainActivity.this, voidActivity.class);
        int START_VOID_ACTIVITY = 5;
        startActivityForResult(intent, START_VOID_ACTIVITY);

    }
    public void endVoid (int vECR, int vREF){
        System.out.print("Working with transaction driver to fin VOID -----");
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this,context);
        td.execute(5,vECR, vREF);

    }
    public void refund (View v){
        System.out.println("Starting Refund.. ");
        Intent intent = new Intent(MainActivity.this, refundActivity.class);
        int START_REFUND_ACTIVITY = 4;
        startActivityForResult(intent, START_REFUND_ACTIVITY);
    }
    public void endRefund(int amount){
        System.out.print("Working with transaction driver to fin REFUND -----");
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this,context);
        td.execute(4,amount);
    }
    public void report(View v){
        System.out.println("Making a report");
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this, context);
        td.execute(3);

    }
    public void lookUp(View view) {
        System.out.println("Looking things up..");
        Intent intent = new Intent(MainActivity.this, activity_lookUp.class);
        int START_LOOKUP_ACTIVITY = 2;
        startActivityForResult(intent, START_LOOKUP_ACTIVITY);

    }
    public void processSale(View view) {
        System.out.println("Starting to build a sale ");
        Intent intent = new Intent(MainActivity.this, saleActivity.class);
        int START_SALE_ACTIVITY = 1;
        startActivityForResult(intent, START_SALE_ACTIVITY);
    }
    public static void retrieveInfo(MainActivity activity,Context context){
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        transaction_Driver td = new transaction_Driver(activity,context); //Create a new transaction driver class
        td.execute(0); //execute the transaction driver thread
    }
    public void endSale(String gtotal){
        System.out.print("Ending sale gonna pea with TD -----");
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this,context);
        double doublet = Double.parseDouble(gtotal)*100;
        int t =(int) doublet ;
        td.execute(1,t); //execute the PaymentEngine thread

    }
    public void endLookUp(int ecr, int ref){
        Context context = getApplicationContext();
        PosLink pLink = POSLinkCreator.createPoslink(context); //Create a new PosLink Object
        //Create a new transaction driver class
        transaction_Driver td = new transaction_Driver(this,context);

        int e = ecr;
        int r = ref;
        td.execute(2, e, r); //execute the transaction driver thread
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("Getting RESULTS NOWW ------ ");
        super.onActivityResult(requestCode, resultCode, data);
        Bundle bundle = data.getExtras();

        switch(requestCode){
            case 1:
                System.out.println("REQUEST CODE: "+requestCode);
                System.out.println("RESULT CODE: "+resultCode);
                String total = bundle.getString("grandTotal");
                System.out.println("Got sale total results: "+total);
                endSale(total);
                break;
            case 2:
                System.out.println("REQUEST CODE: "+requestCode);
                System.out.println("RESULT CODE: "+resultCode);
                int ecr = bundle.getInt("ECR");
                int ref = bundle.getInt("REF");
                System.out.println("Got ECR: "+ecr+" REF: "+ref);
                endLookUp(ecr, ref);
                break;
            case 4:
                System.out.println("REQUEST CODE: "+requestCode);
                System.out.println("RESULT CODE: "+resultCode);
                int rAmount = bundle.getInt("REFUND");

                System.out.println("Got REFUND AMOUNT: "+rAmount);

                endRefund(rAmount);
                break;
            case 5:
                System.out.println("REQUEST CODE: "+requestCode);
                System.out.println("RESULT CODE: "+resultCode);
                int ecrV =  bundle.getInt("ECR_VOID");
                int refV =  bundle.getInt("REF_VOID");

                System.out.println("Got VOID ECR: "+ecrV);
                System.out.println("Got VOID REF: "+refV);



                endVoid(ecrV, refV);
                break;
            default:
                break;
        }

    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
    }
}